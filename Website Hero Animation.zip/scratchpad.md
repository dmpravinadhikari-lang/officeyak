# OfficeYak BD deck — titles (noun-phrase style)
1. OfficeYak — Business development brief
2. The consultancy owner's week
3. What OfficeYak is
4. Three peaks: Grow · Prepare · Run
5. Grow — Leads, board, market
6. Prepare — Attendance, mocks, AI interview, SOP
7. Run — Staff, payroll, offices, reports
8. The AI layer: what the Yak decides
9. Proof: numbers from the product
10. Plans and pricing
11. Who buys, and why (buyer profiles)
12. The visit: a 20-minute script
13. Objections and answers
14. How a consultancy joins (onboarding path)
15. Partner & referral programme
16. Your WhatsApp kit (message to send)
17. Next steps & contacts
