repo: dmpravinadhikari-lang/stride.np
branch: main

## Last sync
date: 2026-09-26T14:29:19Z
### Updated in this project
- Pulled console, market, phone product screenshots into the client deck
- Confirmed brand SVGs and tokens now live in public/brand

## Screen map
| Screen | Repo files |
|---|---|
| Stride Brand Guidelines - Final.dc.html — description & modules | src/lib/brand.ts, src/lib/nav.ts, src/lib/plans.ts, src/components/FeatureBento.tsx, src/components/ServiceShowcase.tsx |
| Stride Brand Guidelines - Final.dc.html — website imagery | public/product/students.png, public/product/attendance.png, public/product/reports.png |
| OfficeYak Client Deck.dc.html — screenshots | public/product/students.png, attendance.png, reports.png, console.png, market.png, phone.png |
