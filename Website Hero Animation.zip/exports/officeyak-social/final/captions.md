# OfficeYak — launch week captions

Post at 11:00 NPT. Image: same name as heading (1080×1080 PNG). Stories: reuse the square + "Link" sticker.

## Day 1 · OfficeYak launch  (day1-launch.png)

**Facebook**

Meet OfficeYak — the AI-powered operating system for education consultancies.

A consultancy in Kathmandu carries 400 student files, 12 classes, three offices and a WhatsApp inbox that never sleeps. OfficeYak carries it: leads, attendance, mock tests, AI interviews, SOPs, HR and payroll on one system — and it rings when something needs you.

Built in Nepal, for consultancies that want to climb like the best in the world.

See how → officeyak.com

**Instagram**

Something has to carry the office. Meet the Yak.

Leads · attendance · mock tests · AI interview · SOP · HR · payroll — one system, built in Nepal.

Link in bio.

#OfficeYak #EducationConsultancy #StudyAbroadNepal

---

## Day 2 · OfficeYak Leads  (day2-leads.png)

**Facebook**

OfficeYak Leads — every walk-in, call and Facebook enquiry lands on one board with a counsellor, a next step, and a date.

Walk-ins convert 2.1× more often when someone calls back within a day. The Yak sorts your morning list by exactly that, so nobody waits and nobody is forgotten.

See the board → officeyak.com

**Instagram**

2.1× — that's how much more a walk-in converts when you call within a day.

OfficeYak Leads tells you who to call first. Every morning.

#OfficeYak #StudentLeads #ConsultancyCRM

---

## Day 3 · OfficeYak Attendance  (day3-attendance.png)

**Facebook**

OfficeYak Attendance — clock in from the office, on your own phone.

Staff and students check in inside a radius you set. Away days carry a reason. Class attendance shows up on the student's file and in the parent view, automatically. And payroll reads the days actually clocked.

No registers, no Excel, no arguments on the 1st of the month.

officeyak.com

**Instagram**

09:02. Clocked in. Inside the office — or it doesn't count.

OfficeYak Attendance: phone check-in with a radius, class attendance on the student file, payroll that reads real days.

#OfficeYak #Attendance #ConsultancyLife

---

## Day 4 · OfficeYak Mock Tests  (day4-mock-tests.png)

**Facebook**

OfficeYak Mock Tests — timed IELTS and PTE sections students sit alone, marked against the published band tables.

The band lands on your board, so you know who is ready to book the real test and who needs two more weeks of Writing. Students practise inside your consultancy, under your name — not on a random app.

See a marked mock → officeyak.com

**Instagram**

Band 7.0. Listening 7.5, Writing 6.5.

"Writing is the one holding your average down." — the Yak, after every mock.

OfficeYak Mock Tests: IELTS & PTE, marked, under your consultancy's name.

#OfficeYak #IELTS #PTE #MockTest

---

## Day 5 · OfficeYak AI Interview  (day5-ai-interview.png)

**Facebook**

OfficeYak AI Interview — the visa interview you don't have four hours a week to sit through.

It has read the student's file. It asks about the sponsor, the study gap, the course choice — and when an answer is thin, it follows up the way a consular officer does. Students rehearse as often as they like; your counsellor reviews the transcript, not the first attempt.

See how it questions → officeyak.com

**Instagram**

"He works in Dubai and sends money home."
"How much, in which month, and which account?"

The Yak follows up when an answer is thin — so the officer in Kathmandu doesn't have to.

OfficeYak AI Interview.

#OfficeYak #VisaInterview #F1Visa #StudyAbroad

---

## Day 6 · OfficeYak SOP Studio  (day6-sop-studio.png)

**Facebook**

OfficeYak SOP Studio — statements scored on the four things an assessor actually reads for: course fit, specificity, funds, ties to Nepal. Plus a check for machine-written prose.

Your counsellor reviews a second draft, not a first. Students stop copying the same eight sentences that get files refused.

See a scored statement → officeyak.com

**Instagram**

Course fit ✓ Funds ✓ Ties to Nepal ✗

That's the line that gets refused. OfficeYak SOP Studio finds it before the assessor does.

#OfficeYak #SOP #StatementOfPurpose #StudyAbroadNepal

---

## Day 7 · OfficeYak Payroll & HR  (day7-payroll-hr.png)

**Facebook**

OfficeYak Payroll & HR — the office itself, carried.

Pay runs in the Nepali month, reading the days your staff actually clocked. SSF, PF, TDS and CIT calculated. Staff, teams and who-can-do-what in one place. Every counsellor's performance measured automatically — leads handled, files moved, students placed — so the owner decides from data, not from who talks loudest.

That's the week. Book a 20-minute demo → officeyak.com

**Instagram**

Asoj 2082 · 24 of 26 days · NPR 61,450 · Paid.

Payroll in the Nepali month, from the days actually clocked. OfficeYak Payroll & HR.

That's the week. Demo link in bio.

#OfficeYak #Payroll #HRNepal #ConsultancyCRM

---

## Profile & bio

Page name: OfficeYak · Handle: @officeyak (fallback @officeyak.np) · Category: Software · Education
Bio: The AI-powered operating system for education consultancies. Leads · attendance · mock tests · AI interview · SOP · HR · payroll. Built in Nepal.
Link: officeyak.com/demo

Files: profile-navy.png (default), profile-yellow.png (campaign weeks), facebook-cover.png (1640×624; keep left 360px clear of text).
